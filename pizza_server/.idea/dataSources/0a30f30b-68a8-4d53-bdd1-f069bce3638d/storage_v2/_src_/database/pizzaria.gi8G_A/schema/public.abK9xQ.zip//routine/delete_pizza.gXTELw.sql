create function delete_pizza(pizza_id integer) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM Pizzas WHERE id = pizza_id;
END;
$$;

alter function delete_pizza(integer) owner to admin;

