create function get_users() returns SETOF users
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM Users;
END;
$$;

alter function get_users() owner to admin;

