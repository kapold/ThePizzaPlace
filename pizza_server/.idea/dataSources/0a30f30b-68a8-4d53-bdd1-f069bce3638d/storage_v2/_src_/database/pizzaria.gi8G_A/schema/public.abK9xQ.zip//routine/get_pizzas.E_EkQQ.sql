create function get_pizzas() returns SETOF pizzas
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM Pizzas;
END;
$$;

alter function get_pizzas() owner to admin;

