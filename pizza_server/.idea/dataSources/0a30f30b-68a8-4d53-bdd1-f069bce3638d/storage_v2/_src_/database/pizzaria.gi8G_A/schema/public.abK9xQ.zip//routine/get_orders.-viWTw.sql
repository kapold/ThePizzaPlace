create function get_orders(status text) returns SETOF orders
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM Orders WHERE Orders.status = $1;
END;
$$;

alter function get_orders(text) owner to admin;

