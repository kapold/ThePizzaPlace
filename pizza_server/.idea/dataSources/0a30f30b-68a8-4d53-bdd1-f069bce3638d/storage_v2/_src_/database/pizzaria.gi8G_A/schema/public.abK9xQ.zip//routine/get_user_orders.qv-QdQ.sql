create function get_user_orders(user_id integer, status text) returns SETOF orders
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM Orders WHERE Orders.user_id = $1 AND Orders.status = $2;
END;
$$;

alter function get_user_orders(integer, text) owner to admin;

