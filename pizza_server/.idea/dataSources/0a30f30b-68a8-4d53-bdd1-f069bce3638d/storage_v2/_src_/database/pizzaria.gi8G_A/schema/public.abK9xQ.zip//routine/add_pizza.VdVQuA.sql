create function add_pizza(n_name text, n_description text, n_price numeric, n_image text) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO Pizzas(name, description, price, image) VALUES (n_name, n_description, n_price, n_image);
END;
$$;

alter function add_pizza(text, text, numeric, text) owner to admin;

