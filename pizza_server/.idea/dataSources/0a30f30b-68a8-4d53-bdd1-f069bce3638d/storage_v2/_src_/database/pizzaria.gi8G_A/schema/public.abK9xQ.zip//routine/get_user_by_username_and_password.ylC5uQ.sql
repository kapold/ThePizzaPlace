create function get_user_by_username_and_password(name_in text, password_in text) returns json
    language plpgsql
as
$$
DECLARE
    result_row record;
BEGIN
    SELECT * INTO result_row FROM users WHERE username = name_in AND password = password_in LIMIT 1;
    IF found THEN
        RETURN json_build_object(
                'id', result_row.id,
                'username', result_row.username,
                'password', result_row.password,
                'phone_number', result_row.phone_number,
                'birthday', result_row.birthday
            );
    ELSE
        RETURN NULL;
    END IF;
END;
$$;

alter function get_user_by_username_and_password(text, text) owner to admin;

