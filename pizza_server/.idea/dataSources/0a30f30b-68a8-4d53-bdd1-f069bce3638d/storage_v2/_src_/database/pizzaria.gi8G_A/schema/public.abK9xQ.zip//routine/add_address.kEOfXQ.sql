create function add_address(new_user_id integer, new_address text) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO DeliveryAddresses(user_id, address) VALUES (new_user_id, new_address);
END;
$$;

alter function add_address(integer, text) owner to admin;

