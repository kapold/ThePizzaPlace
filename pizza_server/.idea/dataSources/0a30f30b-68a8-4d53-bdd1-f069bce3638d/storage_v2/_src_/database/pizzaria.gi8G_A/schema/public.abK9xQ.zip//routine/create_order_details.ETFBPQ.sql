create function create_order_details(n_order_id integer, n_pizza_details_id integer, n_quantity integer, n_product_id integer) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO OrderDetails (order_id, product_id, pizza_details_id, quantity)
        VALUES (n_order_id, n_product_id, n_pizza_details_id, n_quantity);
END;
$$;

alter function create_order_details(integer, integer, integer, integer) owner to admin;

