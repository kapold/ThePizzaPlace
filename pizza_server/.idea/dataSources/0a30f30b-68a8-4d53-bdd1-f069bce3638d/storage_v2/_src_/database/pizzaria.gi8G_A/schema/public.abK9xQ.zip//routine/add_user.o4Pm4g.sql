create procedure add_user(IN p_username character varying, IN p_password character varying, IN p_phone_number character varying, IN p_birthday date)
    language plpgsql
as
$$
BEGIN
    INSERT INTO Users (username, password, phone_number, birthday)
        VALUES (p_username, p_password, p_phone_number, p_birthday);
END;
$$;

alter procedure add_user(varchar, varchar, varchar, date) owner to admin;

