create function update_order_status(n_order_id integer, n_status character varying) returns void
    language plpgsql
as
$$
BEGIN
    UPDATE Orders SET status = n_status WHERE id = n_order_id;
END;
$$;

alter function update_order_status(integer, varchar) owner to admin;

