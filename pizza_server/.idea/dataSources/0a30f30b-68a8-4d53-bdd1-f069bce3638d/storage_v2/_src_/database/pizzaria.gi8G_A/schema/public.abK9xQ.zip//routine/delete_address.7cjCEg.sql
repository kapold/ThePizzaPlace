create function delete_address(address_id integer) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM DeliveryAddresses WHERE id = address_id;
END;
$$;

alter function delete_address(integer) owner to admin;

