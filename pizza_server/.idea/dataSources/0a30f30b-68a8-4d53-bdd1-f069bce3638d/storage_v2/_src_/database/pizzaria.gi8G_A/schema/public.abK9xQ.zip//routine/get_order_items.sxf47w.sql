create function get_order_items(order_id integer) returns SETOF orderdetails
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM OrderDetails WHERE OrderDetails.order_id = $1;
END;
$$;

alter function get_order_items(integer) owner to admin;

