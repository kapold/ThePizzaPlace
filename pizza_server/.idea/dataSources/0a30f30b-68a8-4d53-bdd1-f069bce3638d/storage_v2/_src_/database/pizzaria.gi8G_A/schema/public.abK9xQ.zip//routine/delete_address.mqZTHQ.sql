create function delete_address(user_id_del integer, address_del text) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM DeliveryAddresses WHERE user_id = user_id_del AND address = address_del;
END;
$$;

alter function delete_address(integer, text) owner to admin;

