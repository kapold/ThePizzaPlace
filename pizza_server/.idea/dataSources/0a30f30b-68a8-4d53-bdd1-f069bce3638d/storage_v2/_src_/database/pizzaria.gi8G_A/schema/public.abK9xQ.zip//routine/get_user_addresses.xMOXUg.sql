create function get_user_addresses(user_id integer) returns SETOF deliveryaddresses
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM DeliveryAddresses WHERE DeliveryAddresses.user_id = $1;
END;
$$;

alter function get_user_addresses(integer) owner to admin;

