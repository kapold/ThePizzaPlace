create function create_order(n_user_id integer, n_delivery_id integer, n_status text) returns integer
    language plpgsql
as
$$
    DECLARE
        returned_id INT;
BEGIN
    INSERT INTO Orders (user_id, delivery_id, created_at, status)
        VALUES (n_user_id, n_delivery_id, NOW(), n_status)
    RETURNING Orders.id INTO returned_id;
    RETURN returned_id;
END;
$$;

alter function create_order(integer, integer, text) owner to admin;

