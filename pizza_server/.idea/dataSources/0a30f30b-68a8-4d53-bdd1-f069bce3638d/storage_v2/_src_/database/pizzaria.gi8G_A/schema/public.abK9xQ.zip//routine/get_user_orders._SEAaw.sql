create function get_user_orders(n_user_id integer) returns SETOF orders
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM Orders WHERE Orders.user_id = $1;
END;
$$;

alter function get_user_orders(integer) owner to admin;

