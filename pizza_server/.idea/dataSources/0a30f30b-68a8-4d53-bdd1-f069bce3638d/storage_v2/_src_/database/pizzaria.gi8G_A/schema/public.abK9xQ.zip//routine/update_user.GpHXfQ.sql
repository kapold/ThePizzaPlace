create function update_user(user_id integer, new_username character varying, new_phone_number character varying, new_birthday date) returns void
    language plpgsql
as
$$
BEGIN
UPDATE users SET
                 username = new_username,
                 phone_number = new_phone_number,
                 birthday = new_birthday
WHERE id = user_id;
END;
$$;

alter function update_user(integer, varchar, varchar, date) owner to admin;

