create function get_pizza_details() returns SETOF pizzadetails
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM PizzaDetails;
END;
$$;

alter function get_pizza_details() owner to admin;

