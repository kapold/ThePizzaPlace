create function check_user_exists(username_param text, password_param text) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS(SELECT 1 FROM users WHERE username = username_param AND password = password_param);
END;
$$;

alter function check_user_exists(text, text) owner to admin;

