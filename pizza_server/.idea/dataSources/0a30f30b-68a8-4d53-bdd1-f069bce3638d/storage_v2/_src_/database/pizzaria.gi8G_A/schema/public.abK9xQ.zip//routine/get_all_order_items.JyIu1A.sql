create function get_all_order_items() returns SETOF orderdetails
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM OrderDetails;
END;
$$;

alter function get_all_order_items() owner to admin;

